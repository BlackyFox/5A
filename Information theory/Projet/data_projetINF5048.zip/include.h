#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define mot64 unsigned long int
#define mot32 unsigned int
#define mot16 unsigned short
#define mot08 unsigned char

